import win32com.client
outlook = win32com.client.Dispatch('outlook.application')
mail = outlook.CreateItem(0)
mail.To = '#enter the receiver email here'
mail.cc = '#enter your email here'
mail.Subject = 'Test Auto EMail'
mail.HTMLBody = '<h3 style="color:blue;">This is HTML Body/h3>'
mail.Body = "Some misbehaviour activities have been caught , please check"


mail.send
