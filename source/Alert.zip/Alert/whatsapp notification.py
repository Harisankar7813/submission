import pywhatkit
pywhatkit.sendwhatmsg("#enter the receiver phone number", "alert: Some misbehaviour activity is caught, please check", 12, 14)