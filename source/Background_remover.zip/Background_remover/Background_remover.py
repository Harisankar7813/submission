import cv2
import cvzone
from cvzone.SelfiSegmentationModule import SelfiSegmentation
import os

cap = cv2.VideoCapture(0)
cap.set(3, 640)
cap.set(4, 480)
segmentor = SelfiSegmentation()
imgBg = cv2.imread("images/1.jpg")

while True:
    sucess, img = cap.read()
    imgOut = segmentor.removeBG(img,imgBg, threshold=0.1)

    cv2.imshow("Image Out", imgOut)
    cv2.waitKey(1)
